<a href="admin_dashboard.php">Books</a>
<a href="admin_logout.php">LogOut</a>
</br></br>

<form action="admin_dashboard.php" method="POST">
	<input type="text" name="id" placeholder="Book Id"></br>
	<input type="text" name="book_name" placeholder="Book Name"></br>
	<input type="text" name="author_name" placeholder="Auther Name"></br>
	<input type="submit" name="submit" value="Add Book"></br>
</form>

<?php
	include_once "Crud.php";
	$crud = new Crud();

	if(isset($_POST['submit'])){
		$id = $_POST['id'];
		$book_name = $_POST['book_name'];
		$author_name = $_POST['author_name'];
		
		$result = $crud->execute("INSERT INTO `books`(`ID`, `Books_name`, `Books_author_name`) VALUES ('$id', '$book_name', '$author_name')");

		if($result){
			header("location: admin_dashboard.php");
		}
	}
?>

<?php
	include_once "Crud.php";
	$crud = new Crud();
	$result = $crud->getData("SELECT * FROM books");
?>

<table border="1">
    <tr>
        <td> Book Id </td>
        <td> Book Name </td>
        <td> Book Author</td>
    </tr>  
    <?php
        foreach($result as $key => $res) {
           echo "<tr>";
           echo "<td>".$res['ID']."</td>";
           echo "<td>".$res['Books_name']."</td>"; 
           echo "<td>".$res['Books_author_name']."</td>";  
           echo "<td><a href = 'edit.php?id=$res[ID]' > Edit </td>"; 
           echo "<td><a href = 'delete.php?id=$res[ID]' > Delete </td>";
           echo "</tr>"; 
        }

        
    ?>
</table>