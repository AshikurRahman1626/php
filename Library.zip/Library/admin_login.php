<form action="admin_login.php" method="POST">
	<input type="text" name="username" placeholder="Username"></br>
	<input type="password" name="pass" placeholder="Password"></br>
	<input type="submit" name="submit" value="Login"></br>
</form>

<?php
	include_once "Crud.php";
	$crud = new Crud();

	if(isset($_POST['submit'])){
		$username = $_POST['username'];
		$pass = $_POST['pass'];
		$result = $crud->getData("select * from admin where username = '$username' and pass = '$pass'");

		if($result){
			header("location: admin_dashboard.php");
		}
	}

	
?>