<?php 
	header("location: admin_login.php")
?>