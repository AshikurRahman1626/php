<a href="student_dashboard.php">Dashboard</a>
<a href="contact.php">Contact</a>
<a href="student_logout.php">LogOut</a>
</br>
</br>

Dhanmondi -32 </br>
Daffodill Internationl University </br>
Account Bulding </br>
Secound Floor </br>
Contact : 0170000000 </br>
email : l@diu.edu.bd </br>