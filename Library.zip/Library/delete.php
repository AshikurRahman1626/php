<?php
    include_once 'Crud.php';
    $crud  = new Crud();
    $id = $_GET['id'];
    $result = $crud->execute("DELETE FROM `books` WHERE ID = '$id'");
    if($result){
    	header("location: admin_dashboard.php");
    }
?>