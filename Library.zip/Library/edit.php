<?php
    include_once 'Crud.php';
    $crud = new Crud();
    $id = $_GET['id'];
    $result = $crud->getData("SELECT * FROM books where ID = '$id'");

	foreach($result as $key => $res) {
	    $ID =  $res['ID'];
	    $Books_name = $res['Books_name'];
	    $Books_author_name = $res['Books_author_name']; 
	}
?>

<form action="edit.php" method="POST">
	<input type="text" name="ID" value="<?php echo $ID ?>" />
	<input type="text" name="Books_name" value="<?php echo $Books_name;?>"/>
	<input type="text" name="Books_author_name" value="<?php echo $Books_author_name;?>"/>
	<input type="submit" name="submit" value="Submit"/>
</form>

<?php
	include_once 'Crud.php';
    $crud = new Crud();
		
    if(isset($_POST['submit'])){
    	$ID =  $_POST['ID'];
    	$Books_name =  $_POST['Books_name'];
	    $Books_author_name = $_POST['Books_author_name'];
    	$result = $crud->execute("UPDATE `books` SET `ID`='$ID',`Books_name`='$Books_name',`Books_author_name`='$Books_author_name' WHERE `ID`='$ID'");
	    if($result){
	   		header("Location: admin_dashboard.php");
		  	exit();
    	}
    }
?>

