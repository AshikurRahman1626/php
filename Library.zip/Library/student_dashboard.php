<a href="student_dashboard.php">Dashboard</a>
<a href="contact.php">Contact</a>
<a href="student_logout.php">LogOut</a>

</br> </br>

<?php
	include_once "Crud.php";
	$crud = new Crud();
	$result = $crud->getData("SELECT * FROM books");
?>

<table border="1">
    <tr>
        <td> Book Id </td>
        <td> Book Name </td>
        <td> Book Author</td>
    </tr>  
    <?php
        foreach($result as $key => $res) {
            echo "<tr>";
            echo "<td>".$res['ID']."</td>";
            echo "<td>".$res['Books_name']."</td>"; 
            echo "<td>".$res['Books_author_name']."</td>";
            echo "</tr>"; 
        }

        
    ?>
</table>