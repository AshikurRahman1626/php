<form action="student_login.php" method="POST">
	<input type="text" name="username" placeholder="Username"></br>
	<input type="password" name="pass" placeholder="Password"></br>
	<input type="submit" name="submit" value="Login"></br>
	If you are not a member,
	<a href="student_registration.php">Register Here</a>
</form>

<?php
	include_once "Crud.php";
	$crud = new Crud();

	if(isset($_POST['submit'])){
		$username = $_POST['username'];
		$pass = $_POST['pass'];
		$result = $crud->getData("select * from student where username = '$username' and password = '$pass'");

		if($result){
			header("location: student_dashboard.php");
		}
	}

	
?>