<?php 
	header("location: student_login.php")
?>