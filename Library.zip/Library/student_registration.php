
<form action="student_registration.php" method="POST">
	<input type="text" name="name" id="name" placeholder="Name"/> </br>
	<input type="text" name="username" id="username" placeholder="Username"/> </br>
	<input type="password" name="password" id="password" placeholder="Password"/> </br>
	<input type="email" name="email" id="email" placeholder="Email"/> </br>
	<input type="text" name="phn_number" id="phn_number" placeholder="Phone Number"/> </br>
	<input type="submit" name="submit" value="Register"/>
	Have a Account?
	<a href="student_login.php">login Here</a>
</form>

<?php
	include_once 'Crud.php';
    $crud = new Crud();
    if(isset($_POST['submit'])){
    	$name = $_POST['name'];
    	$username = $_POST['username'];
    	$password = $_POST['password'];
    	$email = $_POST['email'];
    	$phn_number = $_POST['phn_number'];
    	if($name && $username && $password && $email && $phn_number){
    		$result = $crud->execute("INSERT INTO `student`(`name`, `username`, `password`, `email`, `phn_number`) VALUES ('$name','$username','$password','$email','$phn_number') ");
		    if($result){
				header("Location: student_dashboard.php");
	    	}
    	}
    	else{
    		echo "Please Fill Up all the Field";
    	}
	    	
    }
?>