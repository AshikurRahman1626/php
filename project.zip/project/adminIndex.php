<html>
<head>
<link href='adminnIndexndex.css' rel='stylesheet'>
<title> Home Page </title>
    <link href='librarianIndex.css' rel='stylesheet'>
	<!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <script type="text/javascript" src="bootstrap/js/bootstrap.min.js"></script>
	<script type="text/javascript" src="bootstrap/js/jquery.min.js"></script>
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js"></script>
</head>
<body>   
<div id="container">
				<nav class="navbar navbar-expand-sm bg-dark navbar-dark">
  			<ul class="navbar-nav">
   				 <li class="nav-item">
      				<a class="nav-link" href="adminIndex.php"> Home </a>
  			    </li>
    			<li class="nav-item">
      				<a class="nav-link" href="studentList.php"> Check Student List</a>
   				</li>
   				<li class="nav-item">
      				<a class="nav-link" href="bookList.php">Check Book list</a>
   				</li>
   				<li class="nav-item">
      				<a class="nav-link" href="index.php">Logout</a>
   				</li>
   			</ul>
</div>
</body>
</html>