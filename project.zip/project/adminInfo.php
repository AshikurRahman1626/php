<html>
<head>
<title>Admin Info</title>
<link rel="stylesheet" href="info.css">
</head>
<link href='button.css' rel='stylesheet'>
<div id="headerbutton">
				<a  href="index.php"><button type="button" class="button" id="btn">Back</button></a>
			</div>
<body><br> </br><br></br><br> </br><br></br><br> </br><br></br>
<table border="1" align="center" width="40%">
<tr><th  bgcolor="#CD5C5C"><h1> Information about Admin</h1></th></tr>
<tr><th align="left" bgcolor="#3C3E94"><h3>Mr. Y
<img src="download.jpg" align="right" height="100" weidth="100" border="1"/></h3><br>
<b>Email: mry@gmail.com</b><br>
<b>Schedule : 08:00 AM - 2:00 PM</b><br>
<b>Contact Number : 01721345696</b><br>
</th>
</tr>
</table>
</body>
</html>