<?php
session_start();
?>
<html>
	<head> 
    <title> Admin Login Form</title>
	<link rel="stylesheet" type="text/css" href="logAdmin.css">
	</head>
	<body background="library.jpg">
	<div class="loginbox">
	<img src="image1.png" align="center" class="image1">
	<h1> Login Here </h1>
	<form action="adminLoginForm.php" method="POST" >
    <p>User_ID</p>
    <input type="email" name="Email" placeholder="Enter your Email"/> <br>
	<p>Password</p>
	<input type="password" name="Password"placeholder="Enter your Passsword"/> <br><br>
	<input type="submit" value="save" name="submit"/>
	</form>
	</div>
	</body>
</html>

<?php
include_once("config.php");
if(isset($_POST['submit']))
	{
		$Email=$_SESSION['Email']=($_POST['Email']);
		$Password=($_POST['Password']);
		
		$sql="SELECT * FROM admin WHERE Email='$Email' AND Password='$Password' ";
		$result = mysqli_query($con,$sql);
		if(mysqli_num_rows($result)>0)
		{
			while($row=mysqli_fetch_assoc($result))
			{
				header("location: adminIndex.php");
				
			}
		}
		else
		{
			echo "";
		}
	}
?>