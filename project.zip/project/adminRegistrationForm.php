<html>
	<head> 
    <title> Registration Form</title>
	<link rel="stylesheet" type="text/css" href="adminReg.css">
	</head>
	<body background="library.jpg">
	<div class="registrationbox">
	<h1> Register Here </h1>
	<form action="adminRegistrationForm.php" method="POST" >
	<p>Name</p>
    <input type="text" name="Name" placeholder="Enter your Name"/>
	<p>Email</p>
	<input type="email" name="Email" placeholder="Enter your Email"/>
	<p>Password</p>
	<input type="password" name="Password" placeholder="Enter your password"/>
	<p>Phone_number</p>
	<input type="text" name="Phone_number" placeholder="Enter your phone number"/>
	<input type="submit" value="save" name="submit"/>
	</form>
	</div>
	</body>
</html>

<?php
include_once("config.php");
if(isset($_POST['submit']))
	{
		$Name=($_POST['Name']);
		$Email=($_POST['Email']);
		$Password=($_POST['Password']);
		$Phone_number=($_POST['Phone_number']);
		$results = mysqli_query($con,"Insert into admin(Name,Email,Password,Phone_number) values('$Name','$Email','$Password', '$Phone_number')");

		if($results)
		{
			echo "";
		}
		else
		{
			echo"Insert Problem";
		}
	}
?>