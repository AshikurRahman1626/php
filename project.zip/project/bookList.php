<?php
include_once("config.php");
$result = mysqli_query($con,"SELECT * FROM books_info");
?>
<html>
<head>
<link href='button.css' rel='stylesheet'>
<div id="headerbutton">
				<a  href="studentIndex.php"><button type="button" class="button" id="btn">Back</button></a>
				</div>
			<br></br>
<h1>Books Information</h1>
<link rel="stylesheet" type="text/css" href="style.css">
</head>
<body background="library.jpg">

<table border ="I solid" align="center" width="60%" color="blue">
<th bgcolor="blue"> ID </th>
<th bgcolor="blue"> Books_name </th>
<th bgcolor="blue"> Books_author_name </th>
<th bgcolor="blue"> Books_issue_date </th>
<th bgcolor="blue"> Books_return_date </th>
<th bgcolor="blue"> Dpt_of_student </th>




<?php
while ($res=mysqli_fetch_array($result))
{	
	echo "<tr>";
	echo "<td>".$res['ID']."</td>";
	echo "<td>".$res['Books_name']."</td>";
	echo "<td>".$res['Books_author_name']."</td>";
	echo "<td>".$res['Books_issue_date']."</td>";
	echo "<td>".$res['Books_return_date']."</td>";
	echo "<td>".$res['Dpt_of_student']."</td>";
}
echo "</table>","</body>","</html>";
?>