<?php
	$dbhost="localhost";
	$dbuser="root";
	$dbpass="";
	$dbname="library_info";

	$con = mysqli_connect($dbhost,$dbuser,$dbpass,$dbname); 
	if($con)
	{
		echo "";
	}
	else
	{
		echo "Connection Problem";
	}
?>