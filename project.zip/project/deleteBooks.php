<?php
include("config.php");

$id = $_GET['id'];

$result = mysqli_query($con, "DELETE FROM books_info WHERE id=$id");
if($result){
header("Location:showBooks.php");
}
?>