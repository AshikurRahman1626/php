<?php
include("config.php");

$id = $_GET['id'];

$result = mysqli_query($con, "DELETE FROM student_info WHERE id=$id");
if($result){
header("Location:showStudent.php");
}
?>