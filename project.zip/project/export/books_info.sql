-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Dec 11, 2018 at 06:27 AM
-- Server version: 10.1.9-MariaDB
-- PHP Version: 5.6.15

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `library_info`
--

-- --------------------------------------------------------

--
-- Table structure for table `books_info`
--

CREATE TABLE `books_info` (
  `ID` int(11) NOT NULL,
  `Books_name` varchar(30) NOT NULL,
  `Books_author_name` varchar(20) NOT NULL,
  `Books_issue_date` date NOT NULL,
  `Books_return_date` date NOT NULL,
  `Dpt_of_student` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `books_info`
--

INSERT INTO `books_info` (`ID`, `Books_name`, `Books_author_name`, `Books_issue_date`, `Books_return_date`, `Dpt_of_student`) VALUES
(1, 'java', 'xxxx', '2018-02-02', '2018-02-03', 'CSE'),
(5, 'data structure', 'L', '2018-08-09', '2018-08-11', 'EEE'),
(6, 'OOP', 'Mr.Y', '2018-12-29', '2018-12-31', 'TE'),
(12, 'java', 'xxxx', '2018-11-07', '2018-11-17', 'CSE'),
(14, 'English', 'L', '2018-12-04', '2018-12-07', 'SWE'),
(15, 'English', 'L', '2018-12-04', '2018-12-07', 'SWE');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `books_info`
--
ALTER TABLE `books_info`
  ADD PRIMARY KEY (`ID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `books_info`
--
ALTER TABLE `books_info`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
