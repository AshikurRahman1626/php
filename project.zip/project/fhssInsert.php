<html>
	<head> 
    
    <link rel="stylesheet" type="text/css" href="insertStu.css">
	</head>
	<body background="library.jpg">
	<div class="insertbox">
	<h1> Insert Here </h1>
	<form action="fhssInsert.php" method="POST" >
    <p>Books_name</p>
	<input type="text" name="Books_name" placeholder="Enter Books Name"/>
	<p>Books_author_name:</p>
	<input type="text" name="Books_author_name"placeholder="Enter Books Author Name"/><br></br>
	<input type="submit" value="save" name="submit"/>
	</div>
	</form>
	</body>
</html>

<?php
include_once("config.php");
if(isset($_POST['submit']))
	{
		$Books_name=($_POST['Books_name']);
		$Books_author_name=($_POST['Books_author_name']);
		
		$results = mysqli_query($con,"Insert into fhss(Books_name,Books_author_name) values('$Books_name','$Books_author_name')");

		if($results)
		{
			echo header("location:showFHSS.php");
		}
		else
		{
			echo"Insert Problem";
		}
	}
?>