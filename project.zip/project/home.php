<?php
session_start();
if(!$_SESSION['Email'])
{
	header("location:index.php");
}
?>
<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
	<a href="logout.php">logout</a>
</body>
</html>