<html>
<head>
<link href='index.css' rel='stylesheet'>
<title> Home Page </title>
    <link href='style2.css' rel='stylesheet'>
	<!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <script type="text/javascript" src="bootstrap/js/bootstrap.min.js"></script>
	<script type="text/javascript" src="bootstrap/js/jquery.min.js"></script>
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js"></script>
</head>
<body>   


<div id="container">
				<nav class="navbar navbar-expand-sm bg-dark navbar-dark">
<ul class="navbar-nav">
   <li class="nav-item"> 
   <a class="nav-link" href="index.php">Home</a> 
   </li>
   <li> Category of Books 
    <ul class="navbar-nav">
       <li class="nav-item"><a class="nav-link" href="showFHSS.php">Faculty of Humanities & Social Science</a></li>
	   <li class="nav-item"><a class="nav-link" href="showFSIT.php">Faculty of Science & Engineering</a></li>
    </ul>
   </li>
   <li> Category of User 
    <ul class="navbar-nav">
        <li>  Student 
		  <ul class="navbar-nav">
		    <li class="nav-item"><a class="nav-link" href="studentLoginForm.php"> Login </a> </li>
			<li class="nav-item" > <a class="nav-link" href="studentRegistrationForm.php">Registration</a></li>
		  </ul>
		</li>
		<li>  Librarian 
		  <ul class="navbar-nav">
		    <li class="nav-item"> <a  class="nav-link" href="librarianLoginForm.php">Login </a></li>
		  </ul>
		</li>
		<li>  Admin 
		  <ul class="navbar-nav">
		    <li class="nav-item"><a class="nav-link" href="adminLoginForm.php">Login</a></li>
		  </ul></li>
    </ul>
   </li>
   <li> Contact 
   <ul class="navbar-nav">
	   <li class="nav-item"><a  class="nav-link" href="librarianInfo.php"> With Librarian </a></li>
	   <li class="nav-item"><a  class="nav-link" href="adminInfo.php"> With Admin </a></li>
	   </ul>
   </li>
   
</ul>
</div>
</body>
</html>