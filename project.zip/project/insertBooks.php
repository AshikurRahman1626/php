<html>
	<head> 
	<title> Insert Books </title>
	<link rel="stylesheet" type="text/css" href="insertStu.css">
	</head>
	<body background="library.jpg">
	<div class="insertbox">
	<h1> Insert Here </h1>
	<form action="insertBooks.php" method="POST" >
    <p>Books_name</p>
	<input type="text" name="Books_name" id="Books_name"placeholder="Enter Books name" />
	<p>Books Author Name</p>
	<input type="text" name="Books_author_name" id="Name"placeholder="Enter Books Author Name"/>
	
	<p>Books Issue Date</p>
	<input type="date" name="Books_issue_date" id="Email" placeholder="Enter Books issue date"/>
	<p>Books Return Date</p>
	<input type="date" name="Books_return_date" id="Books_return_date" placeholder="Enter books return date"/><br><br>
	<p>Department of Student</p>
	<input type="text" name="Dpt_of_student" id="Dpt_of_student" placeholder="Enter dpt. of student"/><br><br>
	<input type="submit" value="save" name="submit"/>
	</div>
	</form>
	</body>
</html>

<?php
include_once("config.php");
if(isset($_POST['submit']))
	{
		$Books_name=($_POST['Books_name']);
		$Books_author_name=($_POST['Books_author_name']);
		$Books_issue_date=($_POST['Books_issue_date']);
		$Books_return_date=($_POST['Books_return_date']);
		$Dpt_of_student=($_POST['Dpt_of_student']);
		
		$results = mysqli_query($con,"Insert into books_info(Books_name,Books_author_name,Books_issue_date,Books_return_date,Dpt_of_student) values('$Books_name','$Books_author_name','$Books_issue_date','$Books_return_date','$Dpt_of_student')");

		if($results)
		{
			echo header("location:showBooks.php");
		}
		else
		{
			echo"Insert Problem";
		}
	}
?>