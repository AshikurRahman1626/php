<html>
	<head> 
	<title> Insert Student Info</title>
	<link rel="stylesheet" type="text/css" href="insertStu.css">
	</head>
	<body background="library.jpg">
	<div class="insertbox">
	<h1> Insert Here </h1>
	<form action="insertStudent.php" method="POST" >
    <p>Student_ID</p>
	<input type="text" name="Student_ID" id="Student_ID"placeholder="Enter your student id" />
	<p>Name</p>
	<input type="text" name="Name" id="Name"placeholder="Enter your Name"/>
	
	<p>Email</p>
	<input type="email" name="Email" id="Email" placeholder="Enter your email"/>
	<p>Department</p>
	<input type="text" name="Department" id="Department" placeholder="Enter your department"/><br><br>
	<input type="submit" value="save" name="submit"/>
	</form>
	</body>
</html>

<?php
include_once("config.php");
if(isset($_POST['submit']))
	{
		$Student_ID=($_POST['Student_ID']);
		$Name=($_POST['Name']);
		
		$Email=($_POST['Email']);
		$Department=($_POST['Department']);
		
		$results = mysqli_query($con,"Insert into student_info(Student_ID,Name,Email,Department) values('$Student_ID','$Name','$Email','$Department')");

		if($results)
		{
			echo header("location:showStudent.php");
		}
		else
		{
			echo"Insert Problem";
		}
	}
?>