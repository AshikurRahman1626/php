<?php
include_once("config.php");
$result = mysqli_query($con,"SELECT * FROM books_info");
?>
<html>
<head>
<h1>Books Information</h1>
<link rel="stylesheet" type="text/css" href="style.css">
</head>
<body background="library.jpg">

<table border ="I solid" align="center" width="60%" color="blue">

<th bgcolor="blue"> ID </th>
<th bgcolor="blue"> Books_name </th>
<th bgcolor="blue"> Books_author_name </th>
<th bgcolor="blue"> Books_issue_date </th>
<th bgcolor="blue"> Books_return_date </th>
<th bgcolor="blue"> Dpt_of_student </th>
<th bgcolor="blue"> Update </th>
<th bgcolor="blue"> Delete </th>


<?php
while ($res=mysqli_fetch_array($result))
{	
	echo "<tr>";
	echo "<td>".$res['ID']."</td>";
	echo "<td>".$res['Books_name']."</td>";
	echo "<td>".$res['Books_author_name']."</td>";
	echo "<td>".$res['Books_issue_date']."</td>";
	echo "<td>".$res['Books_return_date']."</td>";
	echo "<td>".$res['Dpt_of_student']."</td>";
	echo "<td><a href=\"updateBooks.php?id=$res[ID]\"> Update </a></td>";
	echo "<td><a href=\"deleteBooks.php?id=$res[ID]\"> Delete </a></td></tr>";
}
echo "</table>" ,"</body>","</html>","<br></br>";
?>


