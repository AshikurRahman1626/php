<?php
include_once("config.php");
$result = mysqli_query($con,"SELECT * FROM fhss");
?>

<html>
<head>
<link href='button.css' rel='stylesheet'>
<div id="headerbutton">
				<a  href="index.php"><button type="button" class="button" id="btn">Back to Home</button></a>
				
			</div>
			<br></br>
<h1>FHSS Books Information</h1>
<link rel="stylesheet" type="text/css" href="style.css">
</head>

<body background="library.jpg">
<table border ="I solid" align="center" width="60%" color="blue">
<th bgcolor="#3C3E94"> ID </th>
<th bgcolor="#3C3E94"> Books_name </th>
<th bgcolor="#3C3E94"> Books_author_name </th>


<?php
while ($res=mysqli_fetch_array($result))
{	
	echo "<tr>";
	echo "<td>".$res['ID']."</td>";
	echo "<td>".$res['Books_name']."</td>";
	echo "<td>".$res['Books_author_name']."</td>";
	
}
echo "</table>" ,"</body>","</html>";
?>