<?php
include_once("config.php");
$result = mysqli_query($con,"SELECT * FROM student_info");
?>
<html>
<head>
<link href='button.css' rel='stylesheet'>
<div id="headerbutton">
				<a  href="adminIndex.php"><button type="button" class="button" id="btn">Back</button></a>
			</div>
			<br></br>
<h1>Student List</h1>
<link rel="stylesheet" type="text/css" href="style.css">
</head>
<body background="library.jpg">

<table border ="I solid" align="center" width="60%" color="blue">
<th bgcolor="blue"> ID </th>
<th bgcolor="blue"> Student_ID </th>
<th bgcolor="blue"> Name </th>
<th bgcolor="blue"> Email </th>
<th bgcolor="blue"> Department </th>



<?php
while ($res=mysqli_fetch_array($result))
{	
	echo "<tr>";
	echo "<td>".$res['ID']."</td>";
	echo "<td>".$res['Student_ID']."</td>";
	echo "<td>".$res['Name']."</td>";
	echo "<td>".$res['Email']."</td>";
	echo "<td>".$res['Department']."</td>";
	
}
echo "</table>","</body>","</html>";
?>