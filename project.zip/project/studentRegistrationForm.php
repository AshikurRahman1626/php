<html>
	<head> 
    <title> Registration Form</title>
	<link rel="stylesheet" type="text/css" href="stuReg.css">
	</head>
	<body background="library.jpg">
	<div class="registrationbox">
	<h1> Register Here </h1>
	<form action="studentRegistrationForm.php" method="POST" >
	<p>Name</p>
    <input type="text" name="Name" placeholder="Enter your Name"/>
	<p>Email</p>
	<input type="email" name="Email" placeholder="Enter your Email"/>
	<p>Password</p>
	<input type="password" name="Password" placeholder="Enter your password"/>
	<p>Department</p>
	<input type="text" name="Department" placeholder="Enter your department"/>
	<input type="submit" value="save" name="submit"/>
	</form>
	</div>
	</body>
</html>

<?php
include_once("config.php");
if(isset($_POST['submit']))
	{
		$Name=($_POST['Name']);
		$Email=($_POST['Email']);
		$Password=($_POST['Password']);
		$Department=($_POST['Department']);
		$results = mysqli_query($con,"Insert into student(Name,Email,Password,Department) values('$Name','$Email','$Password', '$Department')");

		if($results)
		{
			header("location:studentLoginForm.php");
		}
		else
		{
			echo"Insert Problem";
		}
	}
?>