<?php
	include_once("config.php");
	if(isset($_POST['update']))
	{
		$Books_name = $_POST['Books_name'];
		$Books_author_name = $_POST['Books_author_name'];
		$Books_issue_date= $_POST['Books_issue_date'];
		$Books_return_date= $_POST['Books_return_date'];
		$Dpt_of_student = $_POST['Dpt_of_student'];
		$id = $_POST["id"];
		$result = mysqli_query($con, "UPDATE books_info SET Books_name = '$Books_name', Books_author_name = '$Books_author_name', Books_issue_date = '$Books_issue_date', Books_return_date = '$Books_return_date', Dpt_of_student='$Dpt_of_student' where id = $id");
		if($result)
		{
			header("location:showBooks.php");
		}
		else
		{
			echo "update error!";
		}
	}
?>	
<?php
	$id = $_GET["id"];
	$result = mysqli_query($con, "SELECT * FROM books_info where id = $id");
	$res=mysqli_fetch_array($result);
		
		$Books_name = $res['Books_name'];
		$Books_author_name = $res['Books_author_name'];
		$Books_issue_date = $res['Books_issue_date'];
		$Books_return_date = $res['Books_return_date'];
		$Dpt_of_student = $res['Dpt_of_student'];
		$id = $res['ID'];
	
	
?>
<form action = "updateBooks.php" method = "POST">
	<input type = "text" name = "Books_name" value = "<?php echo $Books_name; ?>" />
	<input type = "text" name = "Books_author_name" value = "<?php echo $Books_author_name; ?>" />
	<input type = "text" name = "Books_issue_date" value = "<?php echo $Books_issue_date; ?>" />
	<input type = "text" name = "Books_return_date" value = "<?php echo $Books_return_date; ?>" />
	<input type = "text" name = "Dpt_of_student" value = "<?php echo $Dpt_of_student; ?>" />
	<input type = "hidden" name = "id" value = "<?php echo $id; ?>" />
	<input type = "submit" name = "update" value = "Update" />
</form>
