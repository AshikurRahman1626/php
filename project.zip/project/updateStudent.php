<?php
	include_once("config.php");
	if(isset($_POST['update']))
	{
		$Student_ID = $_POST['Student_ID'];
		$Name = $_POST['Name'];
		$Email= $_POST['Email'];
		$Department= $_POST['Department'];
		$id = $_POST["id"];
		$result = mysqli_query($con, "UPDATE student_info SET Student_ID = '$Student_ID', Name = '$Name', Email = '$Email', Department='$Department' where id = $id");
		if($result)
		{
			header("location:showStudent.php");
		}
		else
		{
			echo "update error!";
		}
	}
?>	
<?php
	$id = $_GET["id"];
	$result = mysqli_query($con, "SELECT * FROM student_info where id = $id");
	$res=mysqli_fetch_array($result);
		
		$Student_ID = $res['Student_ID'];
		$Name = $res['Name'];
		$Email = $res['Email'];
		$Department = $res['Department'];
		$id = $res['ID'];
	
	
?>
<form action = "updateStudent.php" method = "POST">
	<input type = "text" name = "Student_ID" value = "<?php echo $Student_ID; ?>" />
	<input type = "text" name = "Name" value = "<?php echo $Name; ?>" />
	<input type = "text" name = "Email" value = "<?php echo $Email; ?>" />
	<input type = "text" name = "Department" value = "<?php echo $Department; ?>" />
	<input type = "hidden" name = "id" value = "<?php echo $id; ?>" />
	<input type = "submit" name = "update" value = "Update" />
</form>
